# Completed project: Drawing paths and shapes

Explore the completed project for the [Drawing paths and shapes](https://developer.apple.com/tutorials/swiftui/drawing-paths-and-shapes) tutorial.
